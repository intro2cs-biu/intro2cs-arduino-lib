# Intro2CS Arduino hardware library

Use this version when compiling a program for an Arduino Uno.

```sh
avr-gcc -mmcu=atmega328p -DF_CPU=16000000UL -Os -std=c99 \
  -Iintro2cs-arduino-lib/headers program.c \
  intro2cs-arduino-lib/intro2cs-arduino-lib.a -o program.elf
```

Include the header belonging to every module used by the program. For serial input and output, include `serial.h` and call `serialBegin(9600)` before using standard C functions such as `printf` or `getchar` from `stdio.h`.
